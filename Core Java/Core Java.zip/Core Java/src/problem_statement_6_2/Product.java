package problem_statement_6_2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.Set;

public class Product {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Hashtable<String,String> ht=new Hashtable<String,String>();
		System.out.println("Enter the product id and name: ");
		for(int i=0;i<10;i++)
		{
			ht.put(in.next(),in.next());
		}
		System.out.println("The product list is:");
		System.out.println(ht);
		System.out.println("Enter the product id to be removed:");
		String id = in.next();
		ht.remove(id);
		System.out.println("Item removed");
		System.out.println("The product list is:");
		System.out.println(ht.toString());
		System.out.println("Enter the product id to be searched:");
		String sid= in.next();
		if(ht.containsKey(sid))
		{
			System.out.println(ht.get(sid));
		}
		else
		{
			System.out.println("do not exist");
		}
	}
}
