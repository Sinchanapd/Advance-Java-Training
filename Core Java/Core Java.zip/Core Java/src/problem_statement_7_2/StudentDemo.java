package problem_statement_7_2;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class StudentDemo {
	
	     public static void main(String args[])throws Exception
	     {
	          BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

	          System.out.println("Enter roll number: ");
	          int roll = Integer.parseInt(br.readLine());
	          System.out.println("\nEnter name: ");
	          String name = br.readLine();
	          System.out.println("\nEnter age: ");
	          int age = Integer.parseInt(br.readLine());
	          System.out.println("\nEnter address: ");
	          String address = br.readLine();
	          Student s = new Student(roll,name,age,address);
	          s.display();
	     }
}