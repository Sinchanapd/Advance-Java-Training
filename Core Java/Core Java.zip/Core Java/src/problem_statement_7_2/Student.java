package problem_statement_7_2;

public class Student {
	int roll,age;
    String name,address;
    Student()
    {
         roll=0;
         name=null;
         age=0;
         address=null;
    }
    Student(int r,String n,int a,String ad) throws Exception
    {
         roll=r;
         address=ad;
         int l,temp=0;
         l = n.length();
         for(int i=0;i<l;i++)
         {
              char ch;
              ch=n.charAt(i);
              if(ch<'A' || ch>'Z' && ch<'a' || ch>'z')
                   temp=1;
         }
         /*���-Checking Name�������*/
         try
         {
              if(temp==1)
            	  throw new NameNotValidException();
              else
            	  name=n;
         }
         catch(NameNotValidException e2)
         {
              System.out.println(e2);
         }
         /*���-Checking Age�������*/
         try
         {
              if(a>=15 && a<=21)
                   age=a;
              else
                   throw new AgeNotWithInRangeException();
         }
         catch(AgeNotWithInRangeException e1)
         {
              System.out.println(e1);
         }
         /*���-Checking none of the fied should be blank�������*/
         try
         {
        	 int len=n.length();
        	 int alen=ad.length();
        	 if(r==0 || len==0 || a==0 || alen==0)
        		 throw new NoneShouldBeBlank();
        	 else
        	 {
        		 roll=r;
        		 name=n;
        		 age=a;
        		 address=ad;
        	 }
         }
         catch(NoneShouldBeBlank e)
         {
        	 System.out.println(e);
         }
    }
    void display()
    {
         System.out.println("roll Name Age Address");
         System.out.println("---------------------");
         System.out.println(roll+" "+name+" "+age+" " +address);
    }
}
