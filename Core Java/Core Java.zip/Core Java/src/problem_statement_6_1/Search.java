package problem_statement_6_1;

import java.util.*;
import java.util.ArrayList;
import java.util.Collections;

public class Search {

	public static void main(String[] args) {
		
		ArrayList<String> arr = new ArrayList<String>();
		Scanner in = new Scanner (System.in);
		System.out.println("Enter the number of Student: ");
		int n=in.nextInt();
		System.out.println("Enter the name of Student: ");
		for(int i=0 ;i<n;i++)
		{
			arr.add(in.next()) ;
		}
		System.out.println("Student list :");
		for (String a:arr)
		{
			System.out.println(a);
		}
		System.out.println("Enter the name of student to be searched : ");
		String str =in.next();
		if(arr.contains(str))
		{
			System.out.println("Student name exist in the list");
		}
		else
		{
			System.out.println("Student name does not exist in the list");
		}
	}

}
