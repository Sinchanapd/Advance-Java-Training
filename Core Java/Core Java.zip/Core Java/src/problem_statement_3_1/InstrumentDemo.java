package problem_statement_3_1;

abstract class Instrument
{
	abstract void play();
}

class Piano extends Instrument
{
	void play()
	{
		System.out.println("Piano is playing tan tan tan tan");
	}
}

class Flute extends Instrument
{
	void play()
	{
		System.out.println("Flute is playing toot toot toot toot");
	}
}

class Guitar extends Instrument
{
	void play()
	{
		System.out.println("Guitar is playing tin tin tin");
	}
}

public class InstrumentDemo {

	public static void main(String[] args) {
		
		Instrument arr[] = new Instrument[10];
		
		for (int i=0; i<10; i++)

		{
			switch (i%3)
			{
				case 0: { arr[i] = new Piano(); break; }
				case 1: { arr[i] = new Flute(); break; }
				case 2: { arr[i] = new Guitar(); break; }
			}
		}

		for (int i=0; i<10; i++)
		{
			

			if (arr[i] instanceof Piano)
			{ 
				System.out.println("Piano is stored at index " + (i+1));
			}

			if (arr[i] instanceof Flute) 
			{ 
				System.out.println("Flute is stored at index " + (i+1));
			}

			if (arr[i] instanceof Guitar) 
			{ 
				System.out.println("Guitar is stored at index " + (i+1)); 
			}
		}
	}

}