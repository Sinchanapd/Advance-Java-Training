package problem_statement_5_1;

public class StringManipulation {
	
	public static void main(String []args)
	{
		String str = "JAVA is Simple";
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		
		String s1[] = str.split("\\s");
		for (String a : s1)
		{
            System.out.print(a.charAt(0));
			System.out.print(" ");
		}
		System.out.println(" ");
		
		
		String[] words = str.split(" ");
		StringBuilder s3= new StringBuilder();
		for (int i = words.length - 1; i >= 0; i--) {
            s3.append(words[i]).append(" ");
        }
		System.out.println(s3);
		
		StringBuilder reverseStr = s3.reverse();
		System.out.println(reverseStr.toString());
		
		System.out.println("Total length is: " + str.length());
	}
}
