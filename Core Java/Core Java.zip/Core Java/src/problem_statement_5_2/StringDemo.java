package problem_statement_5_2;

public class StringDemo {

	public static void main(String[] args) {
		String str = "23  +  45  -  (  343  /  12  ) ";
		
		String s1[] = str.split("\\s");
		for (String a : s1)
		{
            System.out.println(a);
		}
	}

}
