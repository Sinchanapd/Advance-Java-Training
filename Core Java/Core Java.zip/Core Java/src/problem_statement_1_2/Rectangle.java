package problem_statement_1_2;

public class Rectangle {
	int length,breadth,area;
	
	Rectangle(int length,int breadth)
	{
		this.length=length;
		this.breadth=breadth;
	}
	
	void area()
	{
		area=length*breadth;
		System.out.println("Area is "+area);
	}
	
	void display()
	{
		System.out.println("Area of rectangle with length "+length+" and breadth "+breadth+" is "+area);
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}

	public int getArea() {
		return area;
	}

	public void setArea(int area) {
		this.area = area;
	}
}
