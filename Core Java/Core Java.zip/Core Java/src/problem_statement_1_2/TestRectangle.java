package problem_statement_1_2;

import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
	    for(int i=1;i<=5;i++)
	    {
	    	  System.out.println("Enter length of rectangle");
	    	  int len=in.nextInt();
	    	  System.out.println("Enter breadth of rectangle");
	    	  int bre=in.nextInt();
	    	  Rectangle obj = new Rectangle(len,bre);
	    	  obj.area();
	    	  obj.display();
	    }
	}

}
