package problem_statement_1_3;

import java.util.*;

public class TestBook {

	public void createBooks()
	{
		Book bk[] = new Book[2];
		bk[0] = new Book("Java Programing ", 350.50);
		bk[1] = new Book("Let Us C", 200.00);
		System.out.printf("%-20s %s\n","Book Title","Book Price");
		for (int i = 0; i < bk.length; i++)
		{
			bk[i].display();
		}
	}

	public void showBooks() 
	{
		createBooks();
	}

	public static void main(String[] args) {
		TestBook c1 = new TestBook();  
		c1.showBooks();
	}

}
