package problem_statement_1_4;

import java.util.Scanner;

public class Rectangle {
	float length, width;

	Rectangle() {
		length = 1;
		width = 1;
	}
	
	Rectangle(float length, float width)
	{
		this.length=length;
		this.width=width;
	}

	float area() {
		return (length * width);
	}

	float perimeter() {
		return 2 * (length + width);
	}

	public void setValues(float length, float width)
	{
		if (length > 0 && length < 20)
		{
			this.length = length;
		}
		if (width > 0 && width < 20)
		{
			this.width = width;
		}
	}

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		this.width = width;
	}
	
	public static void main(String args[])
	{
		 Scanner sc = new Scanner(System.in);
		 Rectangle obj=new Rectangle(2,4);
		 float perimeter = obj.perimeter();
		 float area = obj.area();
		 //obj.setValues(length,width);
		 
		 System.out.println("Area of rectangle is: "+area);
		 System.out.println("Perimeter of rectangle is: "+perimeter);
	}
}
