package problem_statement_2_3;

public class Array {

	public static void main(String[] args) {
		int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		int sum=0,avg,min=A[0];
		for(int i=0;i<=14;i++)
		{
			sum=sum+A[i];
			A[15]=sum;
		}
		for(int i=0;i<=14;i++)
		{
			avg=sum/14;
			A[16]=avg;
		}
		for(int i=0;i<=14;i++)
		{
			if(A[i]<min)
			{
				min=A[i];
			}
			A[17]=min;
		}
		for(int i=0;i<A.length;i++)
		{
			System.out.print(A[i]+" ");
		}  
		
	}

}
