package problem_statement_4_1;

public class BankAccount {
	int accNo;
	String custName;
	String accType;
	float balance;

	BankAccount(int accNo, String custName, String accType, float balance) {
		this.accNo = accNo;
        this.custName = custName;
        this.accType = accType;
        this.balance = balance;
	}
	
	public BankAccount() {
	       
        this.accNo = 100;
        this.custName = "Sinchana";
        this.accType = "Saving";
        this.balance = 500;
    }

	public void deposit(float amt) {
		if (amt < 0) {
			try {
				throw new NumberFormatException();
			} 
			catch (NumberFormatException nf)
			{
				System.out.println("Negaive Amount cannot be deposited");
			}
		} 
		else
		{
			balance = getBalance() + amt;
			System.out.println("Current balance is = " + balance);
		}
	}

	public void withdraw(float amt) {
		if (amt > 1000) {
			try {
				throw new NumberFormatException();
			} catch (NumberFormatException nf) {
				System.out.println("We cannot withdraw amount insufficient balance ");
			}
		} else {
			balance = getBalance() - amt;
			System.out.println("Current balance is = " + balance);

		}
	}

	public float getBalance() {
		if (balance < 1000) 
		{
			try 
			{
				throw new NumberFormatException();
			} 
			catch (NumberFormatException nw) 
			{
				System.out.println("Balance is low " + balance);
			}
		}

		return balance;
	}
	
	void display()
    {
		System.out.println("Balance is = "+getBalance());   
    }
	
	public static void main(String []args)
	{
		BankAccount b=new BankAccount();
        b.deposit(1000);
        b.display();
        b.withdraw(500);
        b.display();
        b.withdraw(2000);
        b.getBalance();
        b.deposit(-500);
        b.display();
	}
}
