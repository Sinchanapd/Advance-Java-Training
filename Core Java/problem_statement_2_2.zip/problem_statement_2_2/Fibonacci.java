package problem_statement_2_2;

import java.util.*;

public class Fibonacci {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter 2 numbers");
		int firstTerm=in.nextInt();
		int secondTerm=in.nextInt();
		
		int i = 1, n = 13;
	    System.out.println("Fibonacci Series till " + n + " terms:");

	    while (i <= n)
	    {
	    	System.out.print(firstTerm + " ");

	    	int nextTerm = firstTerm + secondTerm;
	    	firstTerm = secondTerm;
	    	secondTerm = nextTerm;

	    	i++;
	    }
	}

}
