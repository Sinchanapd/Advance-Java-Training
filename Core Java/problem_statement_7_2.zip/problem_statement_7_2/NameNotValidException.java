package problem_statement_7_2;

public class NameNotValidException extends Exception {
	
	public String toString()
    {
         return ("Name is not Valid..Please Re-enter the Name");
    }

}