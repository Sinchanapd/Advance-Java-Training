package problem_statement_7_2;

public class NoneShouldBeBlank extends Exception {
	
	public String toString()
    {
         return ("None of the fields should be blank");
    }
}
