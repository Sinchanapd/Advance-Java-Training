package problem_statement_2_1;

import java.util.*;

public class StringDemo {

	public static void main(java.lang.String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String str=in.next();
		System.out.println("Length of the string is: "+str.length());
		
		System.out.println("String in UpperCase: "+str.toUpperCase());
		
		String rev="";
		for(int i=str.length()-1;i>=0;i--)
		{
			rev=rev+str.charAt(i);
		}
		
		if(str.equals(rev))
		{
			System.out.println("The string "+str+" is a palindrome");
		}
		else
		{
			System.out.println("The string "+str+" is not a palindrome");
		}
	}

}
