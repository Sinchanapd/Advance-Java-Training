package problem_statement_6_3;

public class Employee {
	private int EmployeeNo;
	private String EmployeeName;
	private String Address;
	
	Employee(int EmployeeNo, String EmployeeName, String Address)
	{
		super();
		this.EmployeeNo = EmployeeNo;
		this.EmployeeName = EmployeeName;
		this.Address = Address;
	}

	public int getEmployeeNo() {
		return EmployeeNo;
	}

	public void setEmployeeNo(int employeeNo) {
		EmployeeNo = employeeNo;
	}

	public String getEmployeeName() {
		return EmployeeName;
	}

	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}
}
